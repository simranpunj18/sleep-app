import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Button } from 'react-native'

const BedtimeReminderScreen = ({ navigation }) => {
  const [bedtime, setBedtime ] = useState('22:00')//set default bedtime as 10:00 pm

  const calculateTimeRemaining = () => {
    //function to calculate time remaining before bedtime
    const currentTime = newDate();
    const bedtimeParts = bedtime.split(':');
    const bedtimeDate = new Date();
    bedtimeDate.setHours(parseInt(bedtimeParts[0], 10));
    bedtimeDate.setMinutes(parseInt(bedtimeParts[1], 10));

   //Calculate the time remaining until bedtime 
   const timeRemaining = bedtimeSate - currentTime;

   //Convert milliseconds to hours and minutes 
   const hoursRemaing =  Math.floor(timeRemaining / (60*60*1000));
   const minutesRemaining = Math.floor((timeRemaining % (60*60*1000) / (60*1000)))

   return { hoursRemaining, minutesRemaining }
  };
  useEffect(() => {
    const interval = setInterval(() => {
      const {hoursRemaining, minutesRemaining } = calculateTimeRemaining();

      //If bedtime has passed, navigate to a different screen 
      if(hoursRemaining <= 0 && minutesRemaining <= 0){
        navigation.navigate('EncourageSleepScreen')
      }
    } , 1000); //update every second

    //Clear the interval component unmount 
    return () => clearInterval(interval);
  }, [bedtime, navigation]);

  return (
    <View style={styles.container}>
        <Text style={styles.title}>Bedtime Reminder</Text>
        <Text style={styles.timeRemaining}>
        Time Remaining until bedtime: {calculateTimeRemaining().hoursRemaining} hours{' '}
        {calculateTimeRemaining().minutesRemaining} minutes
        </Text>
        <Button title="Change Bedtime" onPress={() => navigation.navigate('ChangeBedtimeScreen')}/>
        </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center',
  },
  title: {
    fontSize: 24, 
    marginBottom: 20,
  },
  timeRemaining: {
      fontSize: 18,
      marginBottom: 20,
  },
});
export default BedtimeReminderScreen;