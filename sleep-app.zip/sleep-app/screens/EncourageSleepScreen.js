import React from 'react'; 
import {View, Text, StyleSheet, Image}  from 'react-native'; 

export default class EncourageSleep extends Component {
  
    constructor(props) {
      super(props);
      this.state = {
        light_theme: true
      };
    }

    componentDidMount(){

    }

render(){
  let props = this.props;
  return(
    <View style={styles.container}>
    <Image source={require/path/to/your/image/sleep_image.png} style={styles.image} />
    <Text style={style.message}> It's bedtime! Get a good night's sleep for a refreshed tommorow.</Text>
    </View>
  );
 } 
} 

const styles = StyleSheet.create({
    container: {
       flex: 1, 
       justifyContent: 'center', 
       alignItems: 'center', 
    },
    image: {
       width: 200, 
       height: 200, 
       marginBottom: 20,
    }, 
    message: {
      fontSize: 18, 
      textAlign: 'center',
    },
});

export default EncourageSleepScreen;