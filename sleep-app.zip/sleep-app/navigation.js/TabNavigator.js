import React from 'react'; 
import { CreateBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons';
import BedtimeReminder from "../screens/Bedtimereminder";
import EncourageSleep from "../screens/EncourageSleepScreen"; 

const Tab = createBottomTabNavigator();

const BottomTabNavigator = () => {
      return(
        <Tab.BottomTabNavigator 
                screenOptions= {({ route }) => ({
                  tabBarIcon: ({focused, color, size}) => {
                    let iconName; 
                    if (route.name === 'BedtimeReminder'){
                      iconName = focused ? 'sleep' : 'sleep-outline';
                    } else if (route.name === 'EncourageSleep'){
                      iconName = focused ? 'encourage': 'encourage-outline';
                    }
                    return <Ionicons name={iconName} size={size} color={color} />
                  },
                })}
                tabBarOptions={{
                  activeTintColor: 'blue', 
                  inactiveTintColor: 'white',
                }}
            >
               <Tab.Screen name="Bedtimereminder" componet={Remimnder} options={{headerShown:false}}/>
               <Tab.Screen name="EncourageSleepScreen" component={EncourageSleep} options = {headerShown:false}}/>
      );
}

export default BottomTabNavigator

